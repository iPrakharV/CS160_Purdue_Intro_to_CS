package lab02_PrakharVerma;
import javax.swing.JOptionPane;

/*
* Prakhar Verma
* CS 16000-01 – 03, Fall Semester 2023
* Lab 02
*
*/
public class StarPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String title = "Star__Pattern";
		
		
		

        String pattern = "\n     *\n    * *\n   * * *\n  * * * *\n * * * * *\n  * * * *\n   * * *\n    * *\n     *";
        
        
        // Problem 5a
        System.out.println("Problem 5a: \n The number of characters in the pattern =" +pattern.length() +"\n");
        
        // Problem 5b
        System.out.println("Problem 5b: \n "+pattern);
        
        //Problem 5b_1
        JOptionPane.showMessageDialog(null, "The number of characters in the pattern is " + pattern.length());
        
        //Problem 5b_2
        JOptionPane.showMessageDialog(null, "Pattern: \n" +pattern);
        
        // Problem 6
        // Program correction done
        
        
        //Problem 7
        int asterisks;
        
        //Problem 8
        int numberOfColumns = 5;
        
        asterisks= numberOfColumns*numberOfColumns;
        
        
        //Problem 9
        
        String Output_1= "The number of * symbols in the lines of the pattern are \n"
        		+ "1, 2, 3, 4, 5, 5, 4, 3, 2, 1\n"
        		+ "The total number of * symbols in the pattern is:";
        		
        System.out.println(Output_1 +asterisks );
        
        //Problem 10
        // Code runs correctly
        
        //Problem 11
        
        String a = JOptionPane.showInputDialog("Enter number of columns for star pattern:");
        numberOfColumns= Integer.parseInt(a);
        
        asterisks= numberOfColumns*numberOfColumns;
        JOptionPane.showMessageDialog(null, "The total number of * symbols in the pattern is: " + asterisks);

        
        Compute_Stars (numberOfColumns);
        
        System.out.println("\n End of lab_02");
        
        
        
        System.exit(0);
	}//end of main
	
	
	public static void Compute_Stars (int numberOfColumns)
	{
		int asterisks= numberOfColumns*numberOfColumns;

		System.out.println("\n \n The total number of * symbols in the pattern is: " + asterisks);
	}

}// end of class
