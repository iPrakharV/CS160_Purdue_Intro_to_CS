/*
* Prakhar Verma
* CS 16000-01 03, Fall Semester 2023
* Lab 7
*
*/

package colors;

public class Applications {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ESPGame game = new ESPGame();
		
		game.guessColor();

	}

}
